class school:
    def engineering(self):
        print('SES')
    def sciences(self):
        print('Im an engineering student!')

def main():
    legon = school()
    print(legon)
    legon.engineering()
    legon.sciences()
