# y = 7 % 3
#
# print(y)
#
# name = input("Enter your name:")
# print("Hello " + name)
#
#
# try:
#     a = int(input("Enter hours:"))
#     b = int(input("Enter rate:"))
#
#
# # if a > 40:
# #     print( a * (b * 1.5))
# # else:
# #     print(a * b)
#
#
# except:
#     print("Error, please enter numeric input")
#
try:
    score = float(input("Please enter your score: "))
    if score >= 0.9:
        print("A")
    elif score >= 0.8:
        print("B")
    elif score >= 0.7:
        print("C")
    elif score >= 0.6:
        print("D")
    else:
        print("You failed!")
except:
    print("ERROR!")
#
# x = "Mawuena"
# print(type(x))
# print(len("Efua Agbesi"))
#
# print(str(46.5))
#
# import math
#
# print(math.pi)
# degree = 90
# radian = degree / 360.0 * 2 * math.pi
# print(radian)
#
# print(math.sqrt(4.0))
#
# for i in range(3):
#     x = input("What was your score?")
#     print(x)
#
# def print_poem():
#     print("All things bright and beautiful!")
#     print("All creatures great and small")
#
# def printlyrics():
#     print_poem()
#
# def addtwo(a, b):
#     y = a + b
#     return y
# x = addtwo(4, 5)
# print(x)

# x = 7
# while x > 2 :
#     print(x)
#     x = x - 1
#     print("The end!")
#
#
# while True:
#     line = input(">")
#     if line == "done":
#         break
#     print(line)
# print("done!")
#
# x = int(input("Type a number:"))
# while x > 4:
#     x = x - 1
#
#     if x < 4:
#         break
#     print(x)
# print("finished!")
#
# while True :
#     line = input(">")
#     if line[0] == "#":
#         continue
#     if line == "done":
#         break
#     print(line)
# print("Done!")


