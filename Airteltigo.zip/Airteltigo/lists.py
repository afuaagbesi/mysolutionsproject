x = 'hi Aku Tamakloe'
y= x.split()
print(y)

print(len(x))
line = "one two three"
thing = line.split()
print(thing)
print(len(thing))
ANDREW = thing[2]
print(ANDREW)
print(id(x))

m = [12, 24, 48, 8, 60, 36]
provisions = list()
provisions.append("milo")
print(provisions)


Longman = dict()
Longman['age'] = 30
Longman['colour'] = 'red'
print(Longman)


name = 'Ama', 'Yaa', 'Aku'
print(name)


