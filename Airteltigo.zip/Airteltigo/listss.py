hostels = {'new': 'Vikings', 'semi': 'Pent', 'old': 'Sarbah'}

print(hostels['new'])

mawuena = hostels.get('old')
print(mawuena)

hostels['toy'] = 'glider'

del hostels["new"]
#for key in hostels:
    #print(key, hostels[key], sep=", ")

for key, value in hostels.items():
    print(key, value, sep=", ")

