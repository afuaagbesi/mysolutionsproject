sval = 123
print(sval + 1)
us = input("US Floor?")
uk = int(us)-1

print("uk floor", uk)

for i in range(3):
    x = int(input("What did you score?"))

    if x < 10:
        print("Sorry, you failed!")
    elif x >= 10:
        print('Congratulations')

print("Enjoy your day")

def agbesi():
    print('Today is a great day')
    print('God is good')
agbesi()

z = int(input('How old are you?'))

if z >= 18:
    print('Have a nice day at work!')
elif z < 18:
    print('Have fun at school!')

agbesi()
