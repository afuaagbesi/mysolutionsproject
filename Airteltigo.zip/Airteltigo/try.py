x = 'ananas'
y = 'a'
if y in x :
    print("True")
else:
    print("False")

a = 'hi '
b = a + 'Agbesi'
print(b)
greeting = "            Hi everyone"
example = greeting.strip()
print(example)
ex2 = greeting.lower()
print (ex2)

stuff = "agbesimefua2003@gmail.com email &"
x = stuff.find("@")
print(x)
z = stuff.find('&')
print(z)
y = stuff.find(' ',z)
print(y)